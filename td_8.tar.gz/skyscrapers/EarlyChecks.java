package skyscrapers;

public class EarlyChecks extends Exploration{

  //To be completed in Ex3

  public EarlyChecks(Architects archi){
    super(archi);
    //To be completed in Ex3
  }

  public State getState(){
    //To be completed in Ex3
    return null;
  }

  public boolean search(){
    //To be completed in Ex3
    return false;
  }

}