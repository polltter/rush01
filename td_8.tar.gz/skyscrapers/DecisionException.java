package skyscrapers;

public class DecisionException extends RuntimeException{
  public DecisionException(String msg){
    super(msg);
  }
}
