package skyscrapers;

public class Naive extends Exploration{

  //To be completed in Ex2

  public Naive(Architects archi){
    super(archi);
    //To be completed in Ex2
  }

  public State getState(){
    //To be completed in Ex2
    return null;
  }

  public boolean search(){
    //To be completed in Ex2
    return false;
  }

}