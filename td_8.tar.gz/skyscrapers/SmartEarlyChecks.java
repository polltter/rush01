package skyscrapers;

public class SmartEarlyChecks extends Exploration{

  //To be completed in Ex4

  public SmartEarlyChecks(Architects archi){
    super(archi);
    //To be completed in Ex4
  }
	
  public State getState(){
    //To be completed in Ex4
    return null;
  }

  public boolean search(){
    //To be completed in Ex4
    return false;
  }

}