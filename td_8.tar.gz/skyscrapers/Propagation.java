package skyscrapers;

import java.util.Queue;
import java.util.LinkedList;

public class Propagation extends Exploration{

  //To be completed in Ex4

  public Propagation(Architects archi){
    super(archi);
    //To be completed in Ex4
  }

  public State getState(){
    //To be completed in Ex4
    return null;
  }

  public boolean search(){
    //To be completed in Ex4
    return false;
  }

  public boolean propagateAndSearch(Pos p,Queue<Action> todo){
    //To be completed in Ex4
    return false;
  }

}